package chain;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class BaseRestImpl {
	
	public static String id;
	
	@BeforeMethod
	public void preConfiguration() {
		

	    
	}

}
