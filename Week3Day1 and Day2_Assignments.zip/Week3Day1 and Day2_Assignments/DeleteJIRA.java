package chain;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DeleteJIRA extends BaseRestImpl { 
	
	@Test(dependsOnMethods="chain.UpdateJIRA.sendPatchRequest")
	public void sendDeleteRequest() {
		
		RestAssured.baseURI = "https://restapitesting.atlassian.net/rest/api/2/issue/";
		RequestSpecification inputRequest = RestAssured
											.given()
											//.param("issue", "10018")
											//.pathParam("id", "10018")
											.auth()
											.preemptive()
										    .basic("smariappanmech@gmail.com", "pZfvTDq7DEY2XVVOu87cB256");
		

		Response response = inputRequest.delete(id);
		
		System.out.println(response.getStatusCode());
		response.prettyPrint();
		
		response.then().assertThat().statusCode(204);
	}

}
