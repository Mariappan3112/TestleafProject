package chain;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllJIRA extends BaseRestImpl {
	
	@Test(dependsOnMethods="chain.CreateNewJIRA.sendPostRequest")
	public void sendGetRequest() {

		RestAssured.baseURI = "https://restapitesting.atlassian.net/rest/api/2/search?JQL=project='TES'";
		
		RequestSpecification inputRequest = RestAssured
				
				.given()
				.param("maxResults", "1")
				.auth()
				.preemptive()
				.basic("smariappanmech@gmail.com", "pZfvTDq7DEY2XVVOu87cB256");
		
				
        Response getResponse = inputRequest.get();		
		
		getResponse.prettyPrint();
		System.out.println("Status Code:" +getResponse.statusCode());
		
		getResponse.then().assertThat().statusCode(200);

}

}
