package chain;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateJIRA extends BaseRestImpl {
	
	@Test(dependsOnMethods="chain.CreateNewJIRA.sendPostRequest")
	
	public void sendPatchRequest() {
		
		RestAssured.baseURI = "https://restapitesting.atlassian.net/rest/api/2/issue/";	
	RequestSpecification inputRequest = RestAssured
											.given()
											.auth()
											.preemptive()
											.basic("smariappanmech@gmail.com", "pZfvTDq7DEY2XVVOu87cB256")
											.contentType(ContentType.JSON)				
											.body
											("{\r\n" + 
													"    \"fields\": {\r\n" + 											
													"    \"description\": \"Issue updated via RestAssured via PUT\"\r\n" + 					
													"   }\r\n" + 
													"}");
		
		Response response = inputRequest.put(id);
		
		System.out.println(response.getStatusCode());
		response.prettyPrint();
		
		//String id = response.jsonPath().get("id");
		//System.out.println("ID:" +id);
		
		response.then().assertThat().statusCode(204);
		
	}

}
